
package tp.i.ia;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;
import java.util.Collections;


public class NoEstado{
    
    private int custoAcumulado;
    private int estadoAtual[][];
    private Random gerador = new Random();     
    private int profundidade;
    private int noIndex;
    private int noPai;
    private int distM;
    private int pecasF;
    
    
    
    //construtor de nós raíz        
    public NoEstado(){
       this.estadoAtual = new int [3][3];
       this.profundidade=0;
       this.noPai= -1;
       this.custoAcumulado=0;
       this.noIndex=0;
       //cria um vetor para gerar as peças
       ArrayList<Integer> disposicaoPecas = new ArrayList<>();
       
       for (int i=1; i<=8; i++){
           //adiciona valores de 1 à 8 no vetor
           disposicaoPecas.add(i);
       }
       //adiciona o espaço vazio
       disposicaoPecas.add(-1); 
       //embaralha as peças
       Collections.shuffle(disposicaoPecas);
       
       int aux = 0;
       
       
        
        
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                //preenche o tabuleiro com um estado aleatório
                this.estadoAtual[i][j] = disposicaoPecas.get(aux);
                aux ++;
            }
        }
    }
    
    public NoEstado(int umEstado[][], int umaProfundidade, int umPai, int umCusto, int umIndex){ //construtor de nós sucessores
        this.estadoAtual=umEstado;
        this.profundidade=umaProfundidade;
        this.noPai=umPai;
        this.pecasF=0;
        this.distM=0;
        this.custoAcumulado = umCusto + 1;
        this.noIndex = umIndex;
        calcularPecasFora();
        calcularDistManhattan();
    }
        
    
    public void setProfundidade(int umaProfundidade){
        this.profundidade=umaProfundidade;
    }
    public void setNoPai(int umPai){
        this.noPai=umPai;
    }
    
    public int getProfundidade(){
        return this.profundidade;
    }
    
    public int getNoPai(){
        return this.noPai;
    }
    
    public void setEstado(int umEstado[][]){
       this.estadoAtual=umEstado;
    }
    
    public int[][] getEstado(){
        return this.estadoAtual;
    }
    
    private void calcularPecasFora(){
        int objetivo [][] = {{1,2,3},{4,5,6},{7,8,-1}};
        for (int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                if (objetivo[i][j] != this.estadoAtual[i][j] && this.estadoAtual[i][j]!= -1){
                    this.pecasF ++;
                }
            }
        }
    }
    
    
    private void calcularDistManhattan(){
        int objetivo [][] = {{1,2,3},{4,5,6},{7,8,-1}};
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                if(objetivo[i][j] != this.estadoAtual[i][j] && this.estadoAtual[i][j]!= -1){
                    for (int m=0; m<3; m++){
                        for (int n=0; n<3; n++){
                            if(objetivo[m][n] == this.estadoAtual[i][j]){
                                this.distM = this.distM + Math.abs( i - m) + Math.abs(j - n);
                                break;
                            }
                        }
                    }
                }
            }
        
        }
    }    
    
    public int getPecasFora(){
        return this.pecasF;
    }
    
    public int getDistManhattan(){
        return this.distM;
    }
    
    public int getEstadoIJ(int i, int j){
        return this.estadoAtual[i][j];
    }
    
    public int getCustoAcumulado(){
        return this.custoAcumulado;
    }
    
    public void setCustoAcumulado(int umCusto){
        this.custoAcumulado = umCusto;
    }

    public int getIndex(){
        return this.noIndex;
    }
    
   public boolean eResolvivel(){
       int inversoes=0;
       int aux [] = new int [9];
       int index=0;
       for(int i=0; i<3; i++){
           for(int j=0; j<3; j++){
                aux[index]=this.estadoAtual[i][j];    
                index++;
            }
        }
       
       for(int i=0; i<aux.length -1; i++){
           for(int j=i+1; j< aux.length; j++){
               if(aux[i]>aux[j]) inversoes ++;
               if(aux[i]==-1 && i % 2 == 1) inversoes++;
           }
           
       }
       return inversoes%2 == 0;
       
   }

    
     
    
    
    

    
}


