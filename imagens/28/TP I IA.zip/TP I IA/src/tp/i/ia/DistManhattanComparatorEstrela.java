/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp.i.ia;

import java.util.Comparator;

/**
 *
 * @author Heitor
 */
public class DistManhattanComparatorEstrela implements Comparator <NoEstado> {
    
    @Override
    public int compare(NoEstado umNo, NoEstado outroNo) {
    if(umNo.getDistManhattan()+umNo.getCustoAcumulado() > outroNo.getDistManhattan() + outroNo.getCustoAcumulado()){
            return 1;
        }
        if(umNo.getDistManhattan() +umNo.getCustoAcumulado() < outroNo.getDistManhattan() + outroNo.getCustoAcumulado()){
            return -1;
        }
        return 0;

//throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}