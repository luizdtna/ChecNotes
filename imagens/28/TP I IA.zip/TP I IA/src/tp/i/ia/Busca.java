/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp.i.ia;
import java.util.ArrayList;
import java.util.*;
/**
 *
 * @author Heitor
 */
public class Busca {
    
    private final int objetivo[][] = {{1,2,3},{4,5,6},{7,8,-1}};
    //atribui valor de indice para cada no
    private int indexCount;
    //valor dos nos expandidos pela busca
    private int nosExpandidos;
    //colecao que recebe o caminho encontrado
    private Stack<NoEstado> caminhoSolucao = new Stack();
    //função para gerar estados sucessores de um estado "n"
    
    private ArrayList<NoEstado> geraSucessores(NoEstado umNo){
        
        //declara lista de estados
        ArrayList<NoEstado> sucessores = new ArrayList<>();
        //procura pelo espaco vazio
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                if(umNo.getEstadoIJ(i,j) == -1){
                    
                    //confere se é possivel "descer o espaco vazio"
                    if(i+1 != 3){     
                        int estadoAux[][] = new int [3][3];
                        for(int l=0; l<3; l++){
                            for(int m=0; m<3; m++){
                                estadoAux[l][m] = umNo.getEstadoIJ(l,m);
                            }
                        }
                        estadoAux[i][j] = estadoAux[i+1][j]; //se sim efetua a troca
                        estadoAux[i+1][j] = -1;
                        indexCount++;
                        sucessores.add(new NoEstado(estadoAux,umNo.getProfundidade()+1,umNo.getIndex(),umNo.getCustoAcumulado(),indexCount));
                    }
                    //confere se é possivel "subir o espaco vazio"    
                    if(i-1 != -1){
                        int estadoAux[][] = new int [3][3];
                        for(int l=0; l<3; l++){
                            for(int m=0; m<3; m++){
                                estadoAux[l][m] = umNo.getEstadoIJ(l,m);
                            }
                        }
                            estadoAux[i][j] = estadoAux[i-1][j]; //se sim efetua a troca
                            estadoAux[i-1][j] = -1;
                            indexCount++;
                            sucessores.add(new NoEstado(estadoAux,umNo.getProfundidade()+1,umNo.getIndex(),umNo.getCustoAcumulado(),indexCount));
                    }
                    //confere se é possivel "mover o espaco vazio para a direita"    
                    if(j+1 != 3){
                        int estadoAux[][] = new int [3][3];
                        for(int l=0; l<3; l++){
                            for(int m=0; m<3; m++){
                                estadoAux[l][m] = umNo.getEstadoIJ(l,m);
                            }
                        }
                        //se sim efetua a troca
                        estadoAux[i][j] = estadoAux[i][j+1];
                        estadoAux[i][j+1] = -1;
                        indexCount++;
                        sucessores.add(new NoEstado(estadoAux,umNo.getProfundidade()+1,umNo.getIndex(),umNo.getCustoAcumulado(),indexCount));
                             
                    } 
                    //confere se é possivel "mover o espaco vazio para a esquerda"
                    if(j-1 != -1){
                        int estadoAux[][] = new int [3][3];
                        for(int l=0; l<3; l++){
                            for(int m=0; m<3; m++){
                                estadoAux[l][m] = umNo.getEstadoIJ(l,m);
                            }
                        }
                        //se sim efetua a troca
                        estadoAux[i][j] = estadoAux[i][j-1];
                        estadoAux[i][j-1] = -1;
                        indexCount++;
                        sucessores.add(new NoEstado(estadoAux,umNo.getProfundidade()+1,umNo.getIndex(),umNo.getCustoAcumulado(),indexCount));
                            
                    }
                    break;
                }
            }
        }
        
    return sucessores;
}
    
    //metodo da Busca em Largura
    public Stack <NoEstado> emLargura(NoEstado umNo){
       
        indexCount=0;
        //define a borda com protocolo FIFO
        Queue<NoEstado> borda = new LinkedList<>();
        //armazena os nós explorados
        Stack<NoEstado> explorados = new Stack ();        
        //confere se o nó raiz é objetivo
        if(Arrays.deepEquals(umNo.getEstado(), objetivo)){ 
            System.out.println("No raiz é objetivo!!!");
            return null;
        }
        //adiciona o nó raiz à borda
        borda.add(umNo);
        //laço de busca
        //enquanto a borda nao estiver fazia, faça:
        while(borda.isEmpty() == false){
            //se a borda iniciar vazia, acusa falha
            if(borda.isEmpty()){
                System.out.println("Borda Vazia!");
                break;
            }
            //remove o primeiro elemento da borda e adiciona aos explorados    
            explorados.push(borda.poll()); 
            //verifica se é objetivo
            if(Arrays.deepEquals(explorados.peek().getEstado(), objetivo)){
                this.nosExpandidos=explorados.size();
                System.out.println("objetivo encontrado");
                caminhoSolucao.push(explorados.pop());
                //pega somente o caminho ate a solucao
                while(explorados.empty()==false){
                    if(caminhoSolucao.peek().getNoPai() == explorados.peek().getIndex()){
                        caminhoSolucao.push(explorados.pop());
                    }
                    else{
                        explorados.pop();
                    }
                        
                }
                //se sim, retorna o caminho ate a solucao
                return caminhoSolucao;
            }
            
            //se nao, adiciona os nós sucessores à borda
            borda.addAll(geraSucessores(explorados.peek()));
        }
        
        return null;
    }
    
    public Stack<NoEstado> emProfundidadeLimitada (NoEstado umNo){
        indexCount=0;
        //define o limite da busca
        int limite=15;
        //define a borda com protocolo FILO
        Stack<NoEstado> borda = new Stack<>();
         //armazena os nós explorados
        Stack<NoEstado> explorados = new Stack ();
        //confere se o nó raiz é objetivo
        if(Arrays.deepEquals(umNo.getEstado(), objetivo)){
            System.out.println("No raiz é objetivo!!!");
            return null;
        }
        //adiciona o nó raiz à borda
        borda.add(umNo);
       
        while(borda.isEmpty() == false){
            //caso a borda inicie vazia, acusa falha
            if(borda.isEmpty()){
                System.out.println("Borda Vazia!");
                break;
            }
            //remove e adiciona o primeiro da borda aos nós explorados
            explorados.push(borda.pop());
            //verifica se o nó atual é objetivo
            if(Arrays.deepEquals(explorados.peek().getEstado(), objetivo)){
                    this.nosExpandidos=explorados.size();
                    System.out.println("objetivo encontrado");
                    caminhoSolucao.push(explorados.pop());
                    //pega somente o caminho ate a solucao
                    while(explorados.empty()==false){
                        if(caminhoSolucao.peek().getNoPai() == explorados.peek().getIndex()){
                            caminhoSolucao.push(explorados.pop());
                        }
                        else{
                            explorados.pop();
                        }
                        
                    }
                    //se sim, retorna o caminho ate a solucao
                    return caminhoSolucao;
                }
            if(explorados.peek().getProfundidade()<=limite){
                //se nao, adiciona os nós sucessores à borda
                borda.addAll(geraSucessores(explorados.peek()));
            } 
        }
        return null;
    }
        
    public Stack<NoEstado> buscaGulosaPecasFora(NoEstado umNo){
        indexCount=0;
        //instancia a borda como uma lista de prioridade ordenada
        //pelo comparador "PecasForaComparator()"
        Queue<NoEstado> borda = new PriorityQueue(200, new PecasForaComparator());
        Stack<NoEstado> explorados = new Stack();
        //confere se o nó raiz é objetivo
        if(Arrays.deepEquals(umNo.getEstado(), objetivo)){
            System.out.println("No raiz é objetivo!!!");
            return null;
        }
        //adiciona o nó raiz à borda
        borda.add(umNo);
            
        while(borda.isEmpty() == false){
            //caso a borda inicie vazia, acusa falha
            if(borda.isEmpty()){
            System.out.println("Borda Vazia!");
            break;
        }
        //remove e adiciona o primeiro da borda aos nós explorados
        explorados.push(borda.poll()); 
        //verifica se o no atual é objetivo
        if(Arrays.deepEquals(explorados.peek().getEstado(), objetivo)){
            this.nosExpandidos=explorados.size();
            System.out.println("objetivo encontrado");
            caminhoSolucao.push(explorados.pop());
            //pega somente o caminho ate a solucao
            while(explorados.empty()==false){
                if(caminhoSolucao.peek().getNoPai() == explorados.peek().getIndex()){
                    caminhoSolucao.push(explorados.pop());
                }
                else{
                    explorados.pop();
                }
                        
            }
            //se sim, retorna o caminho ate a solucao
            return caminhoSolucao;
        }
            //se nao, adiciona os nós sucessores à borda
            borda.addAll(geraSucessores(explorados.peek()));
        }
        return null;
    }
    
    public Stack<NoEstado> buscaGulosaDistManhattan(NoEstado umNo){
        indexCount=0;
        //instancia a borda como uma lista de prioridade ordenada
        //pelo comparador "DistManhattanComparator()"
        Queue <NoEstado> borda = new PriorityQueue(200, new DistManhattanComparator());
        Stack<NoEstado> explorados = new Stack ();
        //confere se o nó raiz é objetivo
        if(Arrays.deepEquals(umNo.getEstado(), objetivo)){
            System.out.println("No raiz é objetivo!!!");
            return null;
        }
        //adiciona o nó raiz à borda
        borda.add(umNo);
            
        while(borda.isEmpty() == false){
            
            if(borda.isEmpty()){
                //caso a borda inicie vazia, acusa falha
                System.out.println("Borda Vazia!");
                break;
            }
            //remove e adiciona o primeiro da borda aos nós explorados
            explorados.push(borda.poll());
        
            if(Arrays.deepEquals(explorados.peek().getEstado(), objetivo)){//verifica se é objetivo
                this.nosExpandidos=explorados.size();
                System.out.println("objetivo encontrado");
                caminhoSolucao.push(explorados.pop());
                //pega somente o caminho ate a solucao
                while(explorados.empty()==false){
                    if(caminhoSolucao.peek().getNoPai() == explorados.peek().getIndex()){
                        caminhoSolucao.push(explorados.pop());
                    }
                    else{
                        explorados.pop();
                    }
                }
            //se sim, retorna o caminho ate a solucao
            return caminhoSolucao;
            }
            
        borda.addAll(geraSucessores(explorados.peek())); //adiciona os nós sucessores à borda
        }
            return null;
    }
    
    public Stack<NoEstado> aEstrelaPecasFora(NoEstado umNo){
        indexCount=0;//conta o indice dos nós
        //instancia a borda como uma lista de prioridade, ordenada pelo comparador
        //"PecasForaComparatorEstrela()", que ordena à partir da f(n) = h(n) + custo acumulado 
        Queue<NoEstado> borda = new PriorityQueue(200, new PecasForaComparatorEstrela()); 
        Stack<NoEstado> explorados = new Stack ();
        //confere se o nó raiz é objetivo
        if(Arrays.deepEquals(umNo.getEstado(), objetivo)){ //confere se o nó raiz é objetivo
            System.out.println("No raiz é objetivo!!!");
            return null;
        }
        //adiciona o nó raiz à borda
        borda.add(umNo);
        
        while(borda.isEmpty() == false){
            if(borda.isEmpty()){
                //caso a borda inicie vazia, acusa falha
                System.out.println("Borda Vazia!");
                break;
            }
            //remove o primeiro da borda e adiciona aos nós explorados
            explorados.push(borda.poll()); 
            //confere se o estado a ser explorado é objetivo
            if(Arrays.deepEquals(explorados.peek().getEstado(), objetivo)){//verifica se é objetivo
                this.nosExpandidos=explorados.size();
                System.out.println("objetivo encontrado");
                caminhoSolucao.push(explorados.pop());
                while(explorados.empty()==false){//pega somente o caminho ate a solucao
                    if(caminhoSolucao.peek().getNoPai() == explorados.peek().getIndex()){
                        caminhoSolucao.push(explorados.pop());
                    }
                    else{
                        explorados.pop();
                    }
                        
                }
                    
                return caminhoSolucao;    //se sim, retorna o caminho ate a solucao
            }
            //se não, explora e adiciona sucessores à borda:
            borda.addAll(geraSucessores(explorados.peek())); 
        }
            
        return explorados;
    }
    
    public Stack<NoEstado> aEstrelaDistManhattan(NoEstado umNo){
        indexCount=0;
        //instancia a borda como uma lista de prioridade, ordenada pelo comparador
        //"DistManhattanComparatorEstrela()", que ordena à partir da f(n) = h(n) + custo acumulado 
        Queue <NoEstado> borda = new PriorityQueue(200, new DistManhattanComparatorEstrela());
        Stack<NoEstado> explorados = new Stack ();
        //confere se o nó raiz é objetivo
        if(Arrays.deepEquals(umNo.getEstado(), objetivo)){
            System.out.println("No raiz é objetivo!!!");
            return null;
        }
        //adiciona o nó raiz à borda
        borda.add(umNo);
        //enquanto a borda não está vazia, faça:
        while(borda.isEmpty() == false){
            //caso a borda inicie vazia, acusa falha
            if(borda.isEmpty()){
                System.out.println("Borda Vazia!");
                break;
            }
            //remove o primeiro da borda e adiciona aos nós explorados
            explorados.push(borda.poll());
            //confere se o estado a ser explorado é objetivo:
            if(Arrays.deepEquals(explorados.peek().getEstado(), objetivo)){ 
                this.nosExpandidos=explorados.size();
                System.out.println("objetivo encontrado");
                caminhoSolucao.push(explorados.pop());
                while(explorados.empty()==false){
                    if(caminhoSolucao.peek().getNoPai() == explorados.peek().getIndex()){
                        caminhoSolucao.push(explorados.pop());
                    }
                    else{
                        explorados.pop();
                    }
                        
                }
                //se sim, retorna o caminho ate a solucao        
                return caminhoSolucao;    
            }
        //se não, explora e adiciona os nós sucessores na borda:
        borda.addAll(geraSucessores(explorados.peek())); 
        }
        return null;
        
    }
        
    public int getNosExpandidos(){
        return this.nosExpandidos;
    }
        
        
        
}
    
    
    
    
