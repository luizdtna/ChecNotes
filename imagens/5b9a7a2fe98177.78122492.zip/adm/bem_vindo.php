<div class="container theme-showcase" role="main">      
  <div class="page-header">
	<h1>Bem vindo</h1>
  </div>
  <div class="row">
		<div class="col-md-12">
			
		</div>
	</div>
</div> <!-- /container -->

